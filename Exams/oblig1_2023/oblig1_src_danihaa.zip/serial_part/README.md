### Serial part

In order to compile and link the serial_main code, make sure to run from the terminal, from *outside* of the `serial_part` or `parallel_part` (i.e., in the same directory as the `makefile`) 

```
make compile_serial
```

To run the executable, run the command

```
make run_serial
```