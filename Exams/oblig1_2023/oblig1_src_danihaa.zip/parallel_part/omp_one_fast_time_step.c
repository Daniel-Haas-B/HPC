#include <omp.h>
#include <stdlib.h>
#define min(a, b) ((a) < (b) ? (a) : (b))

void omp_one_fast_time_step(int nx, int ny, double dx, double dy, double dt,
                            double **u_new, double **u, double **u_prev)
{
  double u_left;
  double u_below;
  double u_right;
  double u_above;
  int u_below_index_i;
  int u_above_index_i;
  double prefac = dt * dt / (8 * dx * dx); // dx = dy so we can use the same prefactor for both x and y.

#pragma omp parallel for private(u_left, u_below, u_right, u_above, u_below_index_i, u_above_index_i) // the private is necessary because the variables are modified in the loop!
  for (int i = 0; i < ny; i++)
  {
    u_below_index_i = abs(i - 1);
    u_above_index_i = min(i + 1, ny - 1 - (i == ny - 1));
    for (int j = 0; j < nx; j++) // this is dumb, needs to be optimized!
    {
      u_left = u[i][abs(j - 1)];
      u_below = u[u_below_index_i][j];
      u_right = u[i][min(j + 1, nx - 1 - (j == nx - 1))]; // this is convoluted but is the essence of the optimization
      u_above = u[u_above_index_i][j];                    // this is convoluted but is the essence of the optimization

      u_new[i][j] = 2 * u[i][j] - u_prev[i][j] + prefac * (u_left + u_right + u_above + u_below - 4 * u[i][j]);
    }
  }
}
